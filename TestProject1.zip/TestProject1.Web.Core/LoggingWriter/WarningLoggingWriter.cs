﻿using Furion.Logging;

namespace TestProject1.Web.Core
{
    public class WarningLoggingWriter : IDatabaseLoggingWriter
    {
        public void Write(LogMessage logMsg, bool flush)
        {
           
        }
    }
}