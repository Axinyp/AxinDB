﻿using Furion.Logging;

namespace TestProject1.Web.Core
{ 
    public  class InfomationLoggingWriter : IDatabaseLoggingWriter
    {
        public void Write(LogMessage logMsg, bool flush)
        {
           
        }
    }
}