﻿
using Furion.Logging;

namespace TestProject1.Web.Core
{
    public class ErrorLoggingWriter : IDatabaseLoggingWriter
    {
        public void Write(LogMessage logMsg, bool flush)
        {
           
        
        }
    }
}