﻿using Furion.Logging;
using Furion.Templates;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1.Web.Core
{
    /// <summary>
    /// 日志输出扩展
    /// </summary>
    public static class LoggingServiceCollecttionExtension
    {

        /// <summary>
        /// 日志输出到文件
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddFileLoggings(this IServiceCollection services)
        {
            Array.ForEach(new[] { LogLevel.Information, LogLevel.Warning, LogLevel.Error }, logLevel =>
            {
                services.AddFileLogging("_log\\{0:yyyy}-{0:MM}-{0:dd}\\{1}.log", options =>
                {
                    options.FileNameRule = fileName => string.Format(fileName, DateTime.UtcNow, logLevel);
                    options.WriteFilter = logMsg => logMsg.LogLevel == logLevel;
                    options.MessageFormat = ( logMsg) =>
                    {
                        var stringBuilder = new StringBuilder();
                        stringBuilder.AppendLine($"##日志时间## {DateTime.Now.ToString("O")}");
                        stringBuilder.AppendLine($"##日志等级## {logLevel}");
                        stringBuilder.AppendLine($"##类名## {logMsg.LogName}");
                        stringBuilder.AppendLine($"##日志内容## {logMsg.Message}");
                        if (!string.IsNullOrEmpty(logMsg.Exception?.ToString()))
                        {
                            stringBuilder.AppendLine($"##异常信息## {logMsg.Exception}");
                        }
                        return stringBuilder.ToString();
                    };
                });
            });
            return services;
        }

        /// <summary>
        /// 日志输出到数据库/其他介质
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection AddOtherLoggings(this IServiceCollection services)
        {
            services.AddDatabaseLogging<InfomationLoggingWriter>(options =>
            {
                options.WriteFilter = (logMsg) =>
                {
                    return logMsg.LogLevel == LogLevel.Information;
                };
            });
            services.AddDatabaseLogging<WarningLoggingWriter>(options =>
            {
                options.WriteFilter = (logMsg) =>
                {
                    return logMsg.LogLevel == LogLevel.Warning;
                };
            });
            services.AddDatabaseLogging<ErrorLoggingWriter>(options =>
            {
                options.WriteFilter = (logMsg) =>
                {
                    return logMsg.LogLevel == LogLevel.Error;
                };
            });
            return services;
        }


       
    }
}
