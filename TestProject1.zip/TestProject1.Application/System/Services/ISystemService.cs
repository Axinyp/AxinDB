﻿namespace TestProject1.Application
{
    public interface ISystemService
    {
        string GetDescription();
    }
}