﻿namespace TestProject1.Application
{
    public class SystemService : ISystemService, ITransient
    {
        public string GetDescription()
        {
            throw Oops.Oh("测试Oh异常输出");
            //throw Oops.Bah("测试Bah异常输出");
            //throw new Exception();

            return "让 .NET 开发更简单，更通用，更流行。";
        }
    }
}