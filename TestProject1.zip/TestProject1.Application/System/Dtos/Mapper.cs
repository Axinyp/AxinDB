﻿namespace TestProject1.Application
{
    public class Mapper : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
        }
    }
}